.. cloudify-cli documentation master file, created by
   sphinx-quickstart on Thu Jun 12 15:30:03 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to cloudify-cli's documentation!
========================================

Contents:

.. toctree::
   :maxdepth: 2

.. automodule:: cosmo_cli.cosmo_cli
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: cosmo_cli.provider_common
   :members:
   :undoc-members:
   :show-inheritance:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

